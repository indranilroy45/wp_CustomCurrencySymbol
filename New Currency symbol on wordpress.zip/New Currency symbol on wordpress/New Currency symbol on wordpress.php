<?php
/*
 * Plugin Name: New Currency symbol on wordpress
 * Plugin URI: https://github.com/indranilroy45
 * Description: A plugin that adds custom currency symbols to your WordPress website
 * Version: 1.0
 * Author: Indranil Roy
 * Author URI: https://catalog.urbd.in/
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

function custom_currency_symbols( $symbols ) {
  // Replace "XXX" with the currency code you want to add
  // Replace "Y" with the currency symbol you want to use
  $symbols['INR-2'] = 'Rs.';
  return $symbols;
}
add_filter( 'woocommerce_currencies', 'custom_currency_symbols' );
